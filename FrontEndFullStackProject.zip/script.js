angular.module('workWizeApp', [])
.controller('MainController', function() {
  var vm = this;

  
  vm.tasks = JSON.parse(localStorage.getItem('tasks')) || [];
  vm.resources = JSON.parse(localStorage.getItem('resources')) || [];


  vm.addTask = function() {
    if (vm.newTaskName && vm.newTaskPriority && vm.newTaskDueDate && vm.newTaskAssignedTo) {
      vm.tasks.push({
        name: vm.newTaskName,
        priority: vm.newTaskPriority,
        dueDate: vm.newTaskDueDate,
        assignedTo: vm.newTaskAssignedTo
      });
      vm.saveTasks();
     
      vm.newTaskName = '';
      vm.newTaskPriority = '';
      vm.newTaskDueDate = '';
      vm.newTaskAssignedTo = '';
    }
  };


  vm.deleteTask = function(index) {
    vm.tasks.splice(index, 1);
    vm.saveTasks();
  };


  vm.editTask = function(index) {
    var task = vm.tasks[index];
    var updatedName = prompt("Update Task Name:", task.name);
    var updatedPriority = prompt("Update Priority (High/Medium/Low):", task.priority);
    var updatedDueDate = prompt("Update Due Date (YYYY-MM-DD):", task.dueDate);
    var updatedAssignedTo = prompt("Update Assigned To:", task.assignedTo);

    if (updatedName && updatedPriority && updatedDueDate && updatedAssignedTo) {
      vm.tasks[index] = {
        name: updatedName,
        priority: updatedPriority,
        dueDate: updatedDueDate,
        assignedTo: updatedAssignedTo
      };
      vm.saveTasks();
    }
  };

  
  vm.addResource = function() {
    if (vm.newResource.trim() !== '') {
      vm.resources.push(vm.newResource);
      vm.saveResources();
      vm.newResource = '';
    }
  };


  vm.deleteResource = function(index) {
    vm.resources.splice(index, 1);
    vm.saveResources();
  };


  vm.saveTasks = function() {
    localStorage.setItem('tasks', JSON.stringify(vm.tasks));
  };


  vm.saveResources = function() {
    localStorage.setItem('resources', JSON.stringify(vm.resources));
  };
});
